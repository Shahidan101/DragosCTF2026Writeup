## Network topology

| IP Address     | Role              | Notes                    |
|----------------|-------------------|--------------------------|
| 192.168.1.10   | HMI               | Authorised Modbus master |
| 192.168.1.20   | PLC               | Modbus slave (unit ID 1) |
| 192.168.1.30   | Historian         | Read-only polling client |
| ?.?.?.?        | Unknown           | Should not be here…      |

## Register map

All values live in Modbus **holding registers** (FC3 read / FC6 write).
Addresses are **0-indexed** as sent on the wire.

| Wire Addr | PLC Label  | Description               | Scale   		| Safe Range    |
|-----------|------------|---------------------------|--------------|---------------|
| `0x0000`  | CL_SETPT   | Chlorine dosing setpoint  | ×0.1 ppm 	| 20 – 40      	|
| `0x0001`  | FLOW_RATE  | Flow rate setpoint        | ×0.1 L/min 	| —          	|
| `0x0002`  | PUMP_SPEED | Pump speed                | ×0.1 Hz 		| —             |
| `0x0003`  | TANK_LEVEL | Tank level                | raw L   		| —             |
| `0x0004`  | ALARM_THRES| High-Cl alarm threshold   | ×0.1 ppm 	| —            	|